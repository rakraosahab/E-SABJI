<?php

    class DBController {
        private $host = "localhost";
        private $user = "root";
        
        private $password = "";
        
        private $database = "e-sabji";
        
        private $conn;
       
        function __construct() {
            $this->conn = $this->connectDB();
        }	
        
        function connectDB() {
            $conn = mysqli_connect("localhost", "root", "", "e-sabji");
            return $conn;
        }
        

        function run($query) {
            $result = mysqli_query($this->conn, $query);
            if($result) {
                return true;
            }
            else {
                return false;
            }
        }
        
        function fetch($query) {
            $resultset = NULL;
            $result = mysqli_query($this->conn, $query);
            if($result) {
                while($row = mysqli_fetch_assoc($result)) {
                    $resultset[] = $row;
                }
                if(!empty($resultset)) {
                    return $resultset;
                }
            }
            else {
                return NULL;
            }
        }
    }
?>